package com.apsareena.lunchtray.ui

interface MyHandler {
    fun goToNextScreen()

    fun cancelOrder()
}

