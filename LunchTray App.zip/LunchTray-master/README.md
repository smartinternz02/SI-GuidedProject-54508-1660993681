# LunchTray

Advanced use cases of app architecture are implemented in this app. 

- Shared view model across fragments in an activity is implemented. 
- Navigation component in android studio is used efficiently to navigate between destinations within the app. 
- Live data and listeners are used for data updation on the display along with the data changes in the database

![lunch_tray](https://user-images.githubusercontent.com/56432777/170812622-3a8f0afc-4e8c-4558-a3f5-1715fb2b552c.jpg)
![1](https://user-images.githubusercontent.com/56432777/170812626-1f6e6058-4151-413c-acd4-4b85315af647.jpg)
![2](https://user-images.githubusercontent.com/56432777/170812629-442d7f4d-9e8f-4e59-b79e-b8ced567fe6b.jpg)
![3](https://user-images.githubusercontent.com/56432777/170812631-b2cecd5b-4ab3-48c9-a83e-bad251d259d5.jpg)
![4](https://user-images.githubusercontent.com/56432777/170812635-52546be0-ed27-4243-a2cb-646560841977.jpg)
