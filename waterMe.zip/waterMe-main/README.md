This is the code for the Water Me app project. 

