package com.example.waterme.model

data class Plant(
    val name: String,
    val schedule: String,
    val type: String,
    val description: String
)
